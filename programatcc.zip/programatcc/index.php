<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="stylesheet" href="css/reset.css">
</head>
<body>

    

<!--Header
---------------------------------------------------------------------------------------------------- -->
    <header class="header">
    <h1 class='h1_header'>Início</h1>
    </header>

    <img class="logoceua" src="img/logoceuremo.png">


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='telas/login.html'">Login</button>
        <button class="btninicio" onclick="window.location.href='telas/cadastro.php'">Cadastro</button>
        <button class="btnbaixo" onclick="window.location.href='telas_interno/login_int.php'">Interno</button>
    </div>


<!--Quadro com inofrmações na tela de inicio
---------------------------------------------------------------------------------------------------- -->
    <div class="quadinicio">
        <img class="brasaoceua" src="img/brasao.png">

        <h1 class="h1scf">Sistema de cadastramento de fornecedores</h1>

        <p class="p1">O cadastramento de fornecedor deve ser iníciado</p>
        <p class="p2">por meio da opção "Cadastro".</p>
        <p class="p3">O processo de cadastramento refere-se</p>
        <p class="p4">ao preenchimento de formulários</p>
        <p class="p5">eletrônicos apropriados.</p>
    </div>

</body>
</html>