
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Documentos</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="stylesheet" href="../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    
    <header class="header">

    <h1 class='h1_header'>Envio de documentos</h1>

    </header>
    <img class="logoceua" src="../img/logoceuremo.png">
    <a onclick="window.location.href='../php/logout.php'" class="logout"> <img class="logout_img" src="../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='opcoes_funcionario.php'">Mandatário</button>
        <button class="btninicio" onclick="window.location.href='empresa.html'">Empresa</button>
        <button class="btninicio_" onclick="window.location.href='documentos.html'">Documentos</button>
        <button class="btninicio" onclick="window.location.href='../gerarpdf/gerar_crc.php'">Emitir C.R.C</button>
    </div>


<!--cadastro documentos
---------------------------------------------------------------------------------------------------- -->
    <div class="quadcadastro">
        
        <form action="" method="POST" enctype="multipart/form-data">
            
        <p class="txtcadastro_doc">Data de validade:</p>
        <input type="date" name="data_validade" class="inputcadastro_doc">
        <p class="txtcadastro_doc">Tipo PDF:</p>
            <select name="tipo_doc" class="inputcadastro_doc" required>
		        <option value="Ato Constitutivo">Ato Constitutivo</option>
		        <option value="Inscrição CNPJ">Inscrição CNPJ</option>
		        <option value="Inscrição Estadual ">Inscrição Estadual</option>
                <option value="Alvará Municipal">Alvará Municipal</option>
                <option value="Negativa Federal">Negativa Federal</option>
                <option value="Negativa Estadual">Negativa Estadual</option>
                <option value="Negativa Municipal">Negativa Municipal</option>
                <option value="Negativa FGTS">Negativa FGTS</option>
                <option value="Negativa Trabalhista">Negativa Trabalhista</option>
                <option value="Negativa de Falência e Concordata">Negativa de Falência e Concordata</option>
                <option value="Balanço Patrimonial">Balanço Patrimonial</option>
                <option value="Atestado de Capacidade técnica">Atestado de Capacidade técnica</option>
                <option value="Inscrição no Conselho de Classe">Inscrição no Conselho de Classe</option>
                <option value="Outros Documentos">Outros Documentos</option>
	        </select>

            <p class="txtcadastro_doc">Arquivo PDF:</p>
            <label for="doc" class="customizar_btnpdf">
            Selecionar
            </label>
            <input type="file" id="doc" name="pdf" accept=".pdf" class="btnpdf_doc" required>

            <p class="nome_arquivo" id="fileName"></p>
            <script>const fileInput = document.getElementById('doc');
            const fileNameDisplay = document.getElementById('fileName');

            fileInput.addEventListener('change', () => {
            const file = fileInput.files[0];
            fileNameDisplay.textContent = file.name;
            });
            </script>

            <input type="submit" class="cadastrar_doc" value="Gravar PDF">
        
            
        </form>
        
    </div>

    <?php
        session_start();
        if (empty($_SESSION)) {
            echo "<script>location.href='../php/cadastro_docs.php';</script>";
        }
        include_once('../php/mysqli.php');
        $logado = $_SESSION['cnpj'];

        if($_SERVER['REQUEST_METHOD']=='POST'){
            include('../php/mysqli.php');

            $data_validade = $_POST['data_validade'];
            $hoje = date('Y/m/d');
            $tipo_doc = $_POST['tipo_doc'];
            $conteudo_pdf = file_get_contents($_FILES['pdf']['tmp_name']);

            $sql_cod_empresa = "SELECT cod_empresa FROM tb_empresa WHERE cnpj = '$logado'";
            $result_cod_empresa = mysqli_query($conn, $sql_cod_empresa);
            $row = mysqli_fetch_assoc($result_cod_empresa);
            $cod_empresa = $row['cod_empresa'];


            //inserir dados no banco

            $sql = "INSERT INTO tb_documentos_pdf (data_validade, data_eamissao, tipo_doc, pdf, tb_empresa_cod_empresa) 
            VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            $stmt->bind_param("ssssi", $data_validade, $hoje, $tipo_doc, $conteudo_pdf, $cod_empresa);


            if($stmt->execute()){
                echo"<script>alert('Dados inseridos com Sucesso');</script>";
            }else{
                echo"<script>alert('Erro ao inserir dados: ".$_SESSION["$stmt->error"]."');</script>";
            }
            

            $stmt->close();
            $conn->close();

            

        }

    ?>

</body>
</html>