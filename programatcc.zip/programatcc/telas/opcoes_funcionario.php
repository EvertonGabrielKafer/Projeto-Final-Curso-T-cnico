<?php

session_start();
if (empty($_SESSION)) {
    echo "<script>location.href='../php/cadastro_banco.php';</script>";
}
include_once('../php/mysqli.php');
$logado = $_SESSION['cpf'];
$sql = "SELECT * FROM tb_funcionario WHERE cpf = '$logado'";
$result = $conn->query($sql);
//print_r($result);

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informações Representante</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="stylesheet" href="../css/reset.css">
</head>
<body>

    

<!--Header
---------------------------------------------------------------------------------------------------- -->
    <header class="header">
    <h1 class='h1_header'>Informações do representante</h1>
        
        </header>
    <img class="logoceua" src="../img/logoceuremo.png">
    <a onclick="window.location.href='../php/logout.php'" class="logout"> <img class="logout_img" src="../img/icons8-sair-48.png"> </a>



<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio_" onclick="window.location.href='opcoes_funcionario.php'">Mandatário</button>
        <button class="btninicio" onclick="window.location.href='empresa.html'">Empresa</button>
        <button class="btninicio" onclick="window.location.href='documentos.html'">Documentos</button>
        <button class="btninicio" onclick="window.location.href='../gerarpdf/gerar_crc.php'">Emitir C.R.C</button>
    </div>



<!--informações cadastrais
---------------------------------------------------------------------------------------------------- -->

<div class="quadcadastro">

        <div class="tabela_info_cadstrais">
        <table border="2">
        <tr>
            <td class="td">Cod</td>
            <td class="td">Nome</td>
            <td class="td">CPF</td>
            <td class="td">RG</td>
            <td class="td">Email</td>
            <td class="td">Telefone</td>
            <td class="td">Data nascimento</td>
            <td class="td">Data emissão</td>
        </tr>
        <?php
        while($user_data = mysqli_fetch_assoc($result))
        {
            echo"<tr>";
            echo"<td class='td'>".$user_data['cod_funcionario']."</td>";
            echo"<td class='td'>".$user_data['nome']."</td>";
            echo"<td class='td'>".$user_data['cpf']."</td>";
            echo"<td class='td'>".$user_data['rg']."</td>";
            echo"<td class='td'>".$user_data['email']."</td>";
            echo"<td class='td'>".$user_data['telefone']."</td>";
            echo"<td class='td'>".$user_data['data_nasc']."</td>";
            echo"<td class='td'>".$user_data['data_emissao']."</td>";
            echo"</tr>";
            
                echo"<td class='tdimg'><a href='alterar.php?cod_funcionario=".$user_data['cod_funcionario']."'><img src='../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
                //echo"<td><a href='../php/excluir_funcionario.php?id=".$user_data['cod_funcionario']."'><img src='../img/icons8-lixeira-48.png' /></a></td>";

                //echo"<td><a href='#'><img src='../img/excluir.png' /></a></td>";
        }
        ?>
        </table>
        </div>
</div>     

</body>
</html>