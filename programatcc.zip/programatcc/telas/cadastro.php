<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="stylesheet" href="../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    
    <header class="header">

    <h1 class='h1_header'>Cadastro de representente</h1>

    </header>

    <img class="logoceua" src="../img/logoceuremo.png">


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='login.html'">Login</button>
        <button class="btnincadastro" onclick="window.location.href='cadastro.php'">Cadastro</button>
        <button class="btnbaixo" onclick="window.location.href='../telas_interno/login_int.php'">Interno</button>
    </div>


<!--cadastro
---------------------------------------------------------------------------------------------------- -->
    <div class="quadcadastrocad">
        

        <h1 class="h1cadastro">Cadastro representante:</h1>

        <form action="../php/cadastro_banco.php" method="post" class="form_principal">
            <p class="txtcadastro">Nome:</p>
            <input type="text" name="cad_nome" class="inputcadastro" maxlength="45" required>
            <p class="txtcadastro">RG:</p>
            <input type="text" name="cad_rg" class="inputcadastro" maxlength="9" required>
            <p class="txtcadastro">Telefone:</p>
            <input type="text" name="cad_telefone" class="inputcadastro" maxlength="14" required>
            <p class="txtcadastro">Data de nascimento:</p>
            <input type="date" name="cad_datanascimento" class="inputcadastro" required>
            
            <div class="form_direita2">
                <p class="txtcadastro_d1">CPF:</p>
                <input type="text" name="cad_cpf" class="inputcadastro_d" maxlength="11" required>
                <p class="txtcadastro_d">E-mail:</p>
                <input type="email" name="cad_email" class="inputcadastro_d" maxlength="45" required>
                <p class="txtcadastro_d">Senha:</p>
                <input type="password" name="cad_senha" class="inputcadastro_d" maxlength="45" required id="cad_senha">
                <p class="txtcadastro_d">Confirmar Senha:</p>
                <input type="password" name="confirm_senha" class="inputcadastro_d" maxlength="45" required id="confirm_senha">
            </div>
            <br>

        
            <input type="submit" class="cadastrar" name="submit" id="submit" value="ENVIAR">
            
        </form>
        
    </div>

</body>
</html>
<script>
    document.querySelector('.form_principal').addEventListener('submit', function(event) {
        const senha = document.getElementById('cad_senha').value;
        const confirmSenha = document.getElementById('confirm_senha').value;

        if (senha !== confirmSenha) {
            alert('As senhas não coincidem!');
            event.preventDefault();
        }
    });
</script>