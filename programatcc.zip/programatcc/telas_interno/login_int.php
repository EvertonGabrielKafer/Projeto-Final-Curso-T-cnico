<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Interno</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="stylesheet" href="../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    <header class="header">

    <h1 class='h1_header'>Acesso interno</h1>

    </header>

    <img class="logoceua" src="../img/logoceuremo.png">


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='../telas/login.html'">Login</button>
        <button class="btninicio" onclick="window.location.href='../telas/cadastro.php'">Cadastro</button>
        <button class="btnbaixoint" onclick="window.location.href='login_int.php'">Interno</button>
    </div>


<!--Quadro do login
---------------------------------------------------------------------------------------------------- -->
    <div class="quadlogin">
        <img class="brasaoceualogin" src="../img/brasao.png">

        <h1 class="h1login_int">Login Interno:</h1>

        <form action="../php/login_banco_interno.php" method="post">
            <p class="txtlogin">CPF:</p>
            <input type="text" id="cpf" name="cpf" class="inputlogin">
            <p class="txtlogin">Senha:</p>
            <input type="password" id="senha" name="senha" class="inputlogin">

        <button class="logar_int">Logar</button>
        </form>
        
    </div>


    

</body>
</html>