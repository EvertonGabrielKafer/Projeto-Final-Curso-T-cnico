<?php


if(!empty($_GET['cod_funcionario']))
{
include_once('../../php/mysqli.php');
//echo "teste";

$cod_funcionario = $_GET['cod_funcionario'];

$sqlconsulta = "select * from tb_funcionario where cod_funcionario=$cod_funcionario";

$result = $conn->query($sqlconsulta);
//echo "teste";
//print_r($result);

if($result->num_rows>0){
    while($user_data = mysqli_fetch_assoc($result))
    {    
    $cad_nome =$user_data['nome'];
    $cad_rg =$user_data['rg'];
    $cad_telefone =$user_data['telefone'];
    $cad_datanascimento =$user_data['data_nasc'];
    $cad_cpf =$user_data['cpf'];
    $cad_email =$user_data['email'];
    $cad_senha =$user_data['senha'];
    }
    //print_r($cad_nome);
}
else{
    header('Location: opcoes_funcionario_2.php');
}


}else{echo"ruinou";}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Cadastro</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    
    <header class="header">

    <h1 class='h1_header'>Alterar o cadastro de represntente</h1>

    </header>

    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio_" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>
        <button class="btninicio" onclick="window.location.href='../interno.html'">Interno</button>
    </div>


<!--cadastro
---------------------------------------------------------------------------------------------------- -->
    <div class="quadcadastro">
        

        <h1 class="h1cadastro">Atualizar Representante:</h1>

        <form action="../../php/php2/atualiza_2.php" method="post" class="form_principal">
            <p class="txtcadastro">Nome:</p>
            <input type="text" name="cad_nome" id="cad_nome" class="inputcadastro" maxlength="45" value="<?php echo $cad_nome ?>" required>
            <p class="txtcadastro">RG:</p>
            <input type="text" name="cad_rg" id="cad_rg" class="inputcadastro" maxlength="9" value="<?php echo $cad_rg ?>" required>
            <p class="txtcadastro">Telefone:</p>
            <input type="text" name="cad_telefone" id="cad_telefone" class="inputcadastro" maxlength="14" value="<?php echo $cad_telefone ?>" required>
            <p class="txtcadastro">Data de nascimento:</p>
            <input type="date" name="cad_datanascimento" id="cad_datanascimento" class="inputcadastro" value="<?php echo $cad_datanascimento ?>" required>
            
            <div class="form_direita2">
                <p class="txtcadastro_d1">CPF:</p>
                <input type="text" name="cad_cpf" id="cad_cpf" class="inputcadastro_d" maxlength="11" value="<?php echo $cad_cpf ?>" required>
                <p class="txtcadastro_d">E-mail:</p>
                <input type="text" name="cad_email" id="cad_email" class="inputcadastro_d" maxlength="45" value="<?php echo $cad_email ?>" required>
                <p class="txtcadastro_d">Senha:</p>
                <input type="password" name="cad_senha" id="cad_senha" class="inputcadastro_d" maxlength="45" id="cad_senha" value="<?php echo $cad_senha ?>" required>
                <p class="txtcadastro_d">Confirmar Senha:</p>
                <input type="password" name="confirm_senha" class="inputcadastro_d" maxlength="45" required id="confirm_senha" value="<?php echo $cad_senha ?>">
            </div>
            <br>

        
            <!--<input type="submit" class="cadastrar" name="submit" id="submit" value="ENVIAR">-->
            <input type="hidden" name="cod_funcionario" value="<?php echo $cod_funcionario ?>">
            <input type="submit" class="cadastrar" name="update" id="update">
            
            
        </form>
        
    </div>

</body>
</html>
<script>
    document.querySelector('.form_principal').addEventListener('submit', function(event) {
        const senha = document.getElementById('cad_senha').value;
        const confirmSenha = document.getElementById('confirm_senha').value;

        if (senha !== confirmSenha) {
            alert('As senhas não coincidem!');
            event.preventDefault();
        }
    });
</script>