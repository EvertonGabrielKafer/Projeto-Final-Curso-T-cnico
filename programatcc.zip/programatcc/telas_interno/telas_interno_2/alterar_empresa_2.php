<?php
if (!empty($_GET['cod_empresa'])) {
    include_once('../../php/mysqli.php');

    $cod_empresa = $_GET['cod_empresa'];

    $sqlconsulta = "SELECT * FROM tb_empresa WHERE cod_empresa = $cod_empresa";
    $result = $conn->query($sqlconsulta);

    if ($result->num_rows > 0) {
        $user_data = mysqli_fetch_assoc($result);

        $nome_empresarial = $user_data['nome_empresarial'] ?? '';
        $cnpj = $user_data['cnpj'] ?? '';
        $porte = $user_data['porte'] ?? '';
        $pais = $user_data['pais'] ?? '';
        $municipio = $user_data['municipio'] ?? '';
        $logradouro = $user_data['logradouro'] ?? '';
        $complemento = $user_data['complemento'] ?? '';
        $telefone = $user_data['telefone'] ?? '';
        $nome_fantasia = $user_data['nome_fantasia'] ?? '';
        $inscricao_estadual = $user_data['inscricao_estadual'] ?? '';
        $descricao_atividades = $user_data['descricao_atividades'] ?? '';
        $estado = $user_data['estado'] ?? '';
        $bairro = $user_data['bairro'] ?? '';
        $numero = $user_data['numero'] ?? '';
        $cep = $user_data['cep'] ?? '';
        $email = $user_data['email'] ?? '';
        $cod_funcionario = $user_data['tb_funcionario_cod_funcionario'];
    } else {
        header('Location: opcoes_empresa_2.php');
        exit();
    }
} else {
    echo "Parâmetro 'cod_empresa' não encontrado.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar empresas</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    
    <header class="header">

    <h1 class='h1_header'>Alterar o cadastro de empresa</h1>

    </header>

    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio_" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>
        <button class="btninicio" onclick="window.location.href='../interno.html'">Interno</button>
    </div>


<!--cadastro
---------------------------------------------------------------------------------------------------- -->
<div class="quadcadastro_">

        <form action="../../php/php2/atualiza_empresa_2.php" method="post" class="form_principal">
            <p class="txtcadastro">Nome empresarial:</p>
            <input type="text" name="nome_empresarial" class="inputcadastro" maxlength="100" value="<?php echo $nome_empresarial ?>" required>
            <p class="txtcadastro">cnpj:</p>
            <input type="number" name="cnpj" class="inputcadastro" maxlength="14" value="<?php echo $cnpj ?>" required>
            <p class="txtcadastro">Porte:</p>
            <select name="porte" class="inputcadastro" value="<?php echo $porte ?>">
		        <option value="MEI">MEI</option>
		        <option value="ME">ME</option>
		        <option value="EPP">EPP</option>
                <option value="DEMAIS">DEMAIS</option>
	        </select>
            <p class="txtcadastro">País:</p>
            <input type="text" name="pais" class="inputcadastro" maxlength="45" value="<?php echo $pais ?>" required>
            <p class="txtcadastro">Município:</p>
            <input type="text" name="municipio" class="inputcadastro" maxlength="45" value="<?php echo $municipio ?>" required>
            <p class="txtcadastro">Logradouro:</p>
            <input type="text" name="logradouro" class="inputcadastro" maxlength="45" value="<?php echo $logradouro ?>" required>
            <p class="txtcadastro">Complemento:</p>
            <input type="text" name="complemento" class="inputcadastro" maxlength="45" value="<?php echo $complemento ?>" required>
            <p class="txtcadastro">Telefone:</p>
            <input type="text" name="telefone" class="inputcadastro" maxlength="14" value="<?php echo $telefone ?>" required>


            <div class="form_direita">
                <p class="txtcadastro_d1">Nome fantasia:</p>
                <input type="text" name="nome_fantasia" class="inputcadastro_d" maxlength="100" value="<?php echo $nome_fantasia ?>"> 
                <p class="txtcadastro_d">Inscrição estadual:</p>
                <input type="number" name="inscricao_estadual" class="inputcadastro_d" maxlength="14" value="<?php echo $inscricao_estadual ?>" required>
                <p class="txtcadastro_d">Descrição de atividades:</p>
                <textarea name="descricao_atividades" class="inputcadastro_d_" maxlength="1000"><?php echo $descricao_atividades ?></textarea>
                <p class="txtcadastro_d2">Estado:</p>
                <input type="text" name="estado" class="inputcadastro_d" maxlength="45" value="<?php echo $estado ?>" required>
                <p class="txtcadastro_d">Bairro:</p>
                <input type="text" name="bairro" class="inputcadastro_d" maxlength="45" value="<?php echo $bairro ?>" required>
                <p class="txtcadastro_d">Número:</p>
                <input type="number" name="numero" class="inputcadastro_d" maxlength="10" value="<?php echo $numero ?>" required>
                <p class="txtcadastro_d">CEP:</p>
                <input type="number" name="cep" class="inputcadastro_d" maxlength="8" value="<?php echo $cep ?>" required>
                <p class="txtcadastro_d">Email:</p>
                <input type="email" name="email" class="inputcadastro_d" maxlength="45" value="<?php echo $email ?>" required>
            </div>
            <br>

        
            <input type="hidden" name="cod_empresa" value="<?php echo $cod_empresa ?>">
            <input type="hidden" name="cod_funcionario" value="<?php echo $cod_funcionario ?>">
            <input type="submit" class="cadastrar_" name="updateempresa" id="update">
            <br><br>
            
        </form>
        
    </div>

</body>
</html>