<?php

session_start();
include_once('../php/mysqli.php');

if(!empty($_GET['search'])){
    $data = $_GET['search'];
    
    $sql = "SELECT * FROM tb_funcionario WHERE cod_funcionario LIKE '%$data%' OR cpf LIKE '%$data%' OR rg LIKE '%$data%' OR nome LIKE '%$data%' ORDER BY cod_funcionario DESC"; 
}
else{
    $sql = "SELECT * FROM tb_funcionario ORDER BY cod_funcionario DESC";

};
$result = $conn->query($sql);
//print_r($result);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Busca Representante</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="stylesheet" href="../css/reset.css">
</head>
<body>

    

<!--Header
---------------------------------------------------------------------------------------------------- -->
<header class="header">

    <div class="box_search">
        <input type="search" class="form_control" placeholder="Buscar representante..." id="pesquisar">
        <button>
            <img class="lupa" onclick="searchData()" src="../img/icons8-pesquisar-24_2.png">
        </button>

    </div>

</header>
    <img class="logoceua" src="../img/logoceuremo.png">
    <a onclick="window.location.href='../php/logout.php'" class="logout"> <img class="logout_img" src="../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    
    <div class="retangulo">
        <button class="btninicio_" onclick="window.location.href='Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio" onclick="window.location.href='buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='relatorio.html'">Relatórios</button>
        <button class="btninicio" onclick="window.location.href='interno.html'">Interno</button>
    </div>


<!--Quadro de aviso
---------------------------------------------------------------------------------------------------- -->
    <div class="quadcadastro">     
            
    <div class="tabela_info_cadstrais">
        <table border="2">
        <tr>
            <td class="td">Cod</td>
            <td class="td">Nome</td>
            <td class="td">CPF</td>
            <td class="td">RG</td>
            <td class="td">Ver mais</td>
            <td class="td">Empresa</td>
            <td class="td">Deletar</td>

        </tr>
        <?php
        while($user_data = mysqli_fetch_assoc($result))
        {
            echo"<tr>";
            echo"<td class='td'>".$user_data['cod_funcionario']."</td>";
            echo"<td class='td'>".$user_data['nome']."</td>";
            echo"<td class='td'>".$user_data['cpf']."</td>";
            echo"<td class='td'>".$user_data['rg']."</td>";
            echo "<td class='td'><a href='telas_interno_2/opcoes_funcionario_2.php?id=".$user_data['cpf']."' target='_blank'>Visualizar</a></td>";
            echo "<td class='td'><a href='telas_interno_2/opcoes_empresa_2.php?cod_funcionario=".$user_data['cod_funcionario']."' target='_blank'>Empresa</a></td>";
            //echo "<td class='td'><a href='../gerarpdf/gerarpdf.php?cod_funcionario=".$user_data['cod_funcionario']."' target='_blank'>Relatório</a></td>";
            echo"<td class='td'><a onclick='deletar(".$user_data['cod_funcionario'].")'><img class='imgopcao' src='../img/icons8-lixeira-48.png' /></a></td>";
            echo"</tr>";
            
                //echo"<td class='tdimg'><a href='alterar.php?cod_funcionario=".$user_data['cod_funcionario']."'><img src='../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
                //echo"<td><a href='../php/excluir_funcionario.php?id=".$user_data['cod_funcionario']."'><img src='../img/icons8-lixeira-48.png' /></a></td>";

                //echo"<td><a href='#'><img src='../img/excluir.png' /></a></td>";
        }
        ?>
        </table>
        
    </div>

</body>

<script>
    var search = document.getElementById('pesquisar');

    search.addEventListener("keydown", function(event){
        if (event.key === "Enter"){
            searchData();
        }
    });

    function searchData(){
        window.location = 'buscar_funcionario.php?search='+search.value;
    }
</script>
<script>
    function deletar(cod_funcionario){
        if(confirm("AVISO: Esta exclusão do representante também resultará na exclusão de sua empresa e documantos relacionados, Deseja realmente excluir?")){
            location.href="../php/php2/excluir_funcionario.php?cod_funcionario="+cod_funcionario;
        }
    }
</script>

</html>