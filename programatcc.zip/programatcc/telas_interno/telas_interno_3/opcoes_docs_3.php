<?php

session_start();

//if (empty($_SESSION)) {
    //echo "<script>location.href='../telas/cadastro_docs.php';</script>";
//}

include_once('../../php/mysqli.php');

$logado = $_GET['cnpj'];
//$_SESSION['cnpj'] = $logado;

$sql_cod_empresa = "SELECT cod_empresa FROM tb_empresa WHERE cnpj = '$logado'";
$result_cod_empresa = mysqli_query($conn, $sql_cod_empresa);
$row = mysqli_fetch_assoc($result_cod_empresa);
$cod_empresa = $row['cod_empresa'];

$sql = "SELECT * FROM tb_documentos_pdf WHERE tb_empresa_cod_empresa = '$cod_empresa'";
$result = $conn->query($sql);
//print_r($result);

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informações Documentos</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>

    

<!--Header
---------------------------------------------------------------------------------------------------- -->
    <header class="header">
    <h1 class='h1_header'>Visualizar Documentos</h1>
        
        </header>
    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>



<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio_" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>

        <button class="btninicio" onclick="window.location.href='../interno.html'">Interno</button>
    </div>



<!--informações cadastrais
---------------------------------------------------------------------------------------------------- -->

<div class="quadcadastro_">

        <div class="tabela_info_cadstrais">
        <table border="2">
        <tr>
            <td class="td">Data validade</td>
            <td class="td">Data emissão</td>
            <td class="td">Tipo documento</td>
            <td class="td">PDF</td>
        </tr>
        <?php
        while($user_data = mysqli_fetch_assoc($result))
        {
            echo"<tr>";
            echo"<td class='td'>".$user_data['data_validade']."</td>";
            echo"<td class='td'>".$user_data['data_eamissao']."</td>";
            echo"<td class='td'>".$user_data['tipo_doc']."</td>";
            echo "<td class='td'><a href='../../php/visualizar_pdf.php?id=".$user_data['cod_doc']."' target='_blank'>Visualizar PDF</a></td>";
            //echo"<td><a href='../php/excluir_doc.php?cod_doc=".$user_data['cod_doc']."'><img src='../img/icons8-lixeira-48.png' /></a></td>";
            //echo"<td class='tdimg'><a href='alterar_doc.php?cod_funcionario=".$user_data['cod_doc']."'><img src='../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
            echo"<td class='td'><a href='alterar_doc_3.php?cod_doc=".$user_data['cod_doc']."'><img class='imgopcao' src='../../img/icons8-editar-64.png' /></a></td>";
            echo"<td class='td'><a onclick='deletar(".$user_data['cod_doc'].")'><img class='imgopcao' src='../../img/icons8-lixeira-48.png' /></a></td>";
            echo"</tr>";
            
                //echo"<td class='tdimg'><a href='alterar.php?cod_funcionario=".$user_data['cod_funcionario']."'><img src='../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
                //echo"<td><a href='#'><img src='../img/excluir.png' /></a></td>";
        }
        ?>
        <br><br>
        </table>
        </div>
</div>   
<script>
    function deletar(cod_doc){
        if(confirm("Deseja deletar?")){
            location.href="../../php/php3/excluir_doc_3.php?cod_doc="+cod_doc;
        }
    }
</script>
</body>
</html>