<?php

if(!empty($_GET['cod_doc']))
{
include_once('../../php/mysqli.php');
//echo "teste";

$cod_doc = $_GET['cod_doc'];

$sqlconsulta = "select * from tb_documentos_pdf where cod_doc=$cod_doc";

$result = $conn->query($sqlconsulta);
//echo "teste";
//print_r($result);

if($result->num_rows>0){
    while($user_data = mysqli_fetch_assoc($result))
    {    
    $cod_doc =$user_data['cod_doc'];
    $data_validade =$user_data['data_validade'];
    $tipo_doc =$user_data['tipo_doc'];
    $pdf =$user_data['pdf'];
    $cod_empresa = $user_data['tb_empresa_cod_empresa'];
    }
    //print_r($cad_doc);
}
else{
    header('Location: opcoes_docs.php');
}
$sqlconsulta_empresa = "select cnpj from tb_empresa where cod_empresa=$cod_empresa";
$empresa = $conn->query($sqlconsulta_empresa);
$res=$empresa->fetch_object();
$cnpj=$res->cnpj;


}else{echo"ruinou";}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Documentos</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    
    <header class="header">

    <h1 class='h1_header'>Editar documento</h1>

    </header>
    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio_" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>
        <button class="btninicio" onclick="window.location.href='../interno.html'">Interno</button>
    </div>


<!--cadastro documentos
---------------------------------------------------------------------------------------------------- -->
    <div class="quadcadastro">
        
        <form action="../../php/php3/atualiza_doc_3.php" method="POST" enctype="multipart/form-data">
            
        <p class="txtcadastro_doc">Data de validade:</p>
        <input type="date" name="data_validade" class="inputcadastro_doc" value="<?php echo $data_validade ?>" >
        <p class="txtcadastro_doc">Tipo PDF:</p>
            <select name="tipo_doc" class="inputcadastro_doc" required value="<?php echo $tipo_doc ?>" >
		        <option value="Ato Constitutivo">Ato Constitutivo</option>
		        <option value="Inscrição CNPJ">Inscrição CNPJ</option>
		        <option value="Inscrição Estadual ">Inscrição Estadual </option>
                <option value="Alvará Municipal">Alvará Municipal</option>
                <option value="Negativa Federal">Negativa Federal</option>
                <option value="Negativa Estadual">Negativa Estadual</option>
                <option value="Negativa Municipal">Negativa Municipal</option>
                <option value="Negativa FGTS">Negativa FGTS</option>
                <option value="Negativa Trabalhista">Negativa Trabalhista</option>
                <option value="Negativa de Falência e Concordata">Negativa de Falência e Concordata</option>
                <option value="Balanço Patrimonial">Balanço Patrimonial</option>
                <option value="Atestado de Capacidade técnica">Atestado de Capacidade técnica</option>
                <option value="Inscrição no Conselho de Classe">Inscrição no Conselho de Classe</option>
                <option value="Outros Documentos">Outros Documentos</option>
	        </select>

            <p class="txtcadastro_doc">Arquivo PDF:</p>
            <label for="doc" class="customizar_btnpdf" value="" >
            Selecionar
            </label>
            <input type="file" id="doc" name="pdf" accept=".pdf" class="btnpdf_doc" required>

            <p class="nome_arquivo" id="fileName"></p>
            <script>const fileInput = document.getElementById('doc');
            const fileNameDisplay = document.getElementById('fileName');

            fileInput.addEventListener('change', () => {
            const file = fileInput.files[0];
            fileNameDisplay.textContent = file.name;
            });
            </script>
            <input type="hidden" name="cod_doc" value="<?php echo $cod_doc; ?>">
            <input type="hidden" name="cnpj" value="<?php $cnpj ?>">
            <input type="submit" class="cadastrar_doc" value="Atualizar">
        
            
        </form>
        
    </div>

</body>
</html>