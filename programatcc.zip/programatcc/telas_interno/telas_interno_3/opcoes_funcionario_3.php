<?php
session_start();
include_once('../../php/mysqli.php');


if (isset($_GET['id'])) {
    $tb_funcionario_cod_funcionario = $_GET['id'];
    
    $sql = "SELECT * FROM tb_funcionario WHERE cod_funcionario = '$tb_funcionario_cod_funcionario'";
    $result = $conn->query($sql);
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informações Representante</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>

    

<!--Header
---------------------------------------------------------------------------------------------------- -->
    <header class="header">
    <h1 class='h1_header'>Informações do representante</h1>
        
        </header>
    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>



<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio_" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>
        <button class="btninicio" onclick="window.location.href='../interno.html'">Interno</button>
    </div>



<!--informações cadastrais
---------------------------------------------------------------------------------------------------- -->

<div class="quadcadastro">

        <div class="tabela_info_cadstrais">
        <table border="2">
        <tr>
            <td class="td">Cod</td>
            <td class="td">Nome</td>
            <td class="td">CPF</td>
            <td class="td">RG</td>
            <td class="td">Email</td>
            <td class="td">Telefone</td>
            <td class="td">Data nascimento</td>
            <td class="td">Data emissão</td>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            
            while ($user_data = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td class='td'>" . $user_data['cod_funcionario'] . "</td>";
                echo "<td class='td'>" . $user_data['nome'] . "</td>";
                echo "<td class='td'>" . $user_data['cpf'] . "</td>";
                echo "<td class='td'>" . $user_data['rg'] . "</td>";
                echo "<td class='td'>" . $user_data['email'] . "</td>";
                echo "<td class='td'>" . $user_data['telefone'] . "</td>";
                echo "<td class='td'>" . $user_data['data_nasc'] . "</td>";
                echo "<td class='td'>" . $user_data['data_emissao'] . "</td>";
                echo "</tr>";
                //echo"<td class='tdimg'><a href='alterar_2.php?cod_funcionario=".$user_data['cod_funcionario']."'><img src='../../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
        }}
    
        ?>
        </table>
        </div>
</div>     

</body>
</html>