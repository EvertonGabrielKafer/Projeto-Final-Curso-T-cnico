<?php

session_start();
include_once('../../php/mysqli.php');
if (isset($_GET['cnpj'])) {
    $_SESSION['cnpj'] = $_GET['cnpj'];
}


include_once('../../php/mysqli.php');
$cod_empresa = $_GET['cod_empresa'];

$sql = "SELECT * FROM tb_empresa WHERE cod_empresa = '$cod_empresa'";
$result = $conn->query($sql);
//print_r($result);

$sql_segunda_tabela = "SELECT pais, estado, municipio, bairro, logradouro, numero FROM tb_empresa WHERE cod_empresa = '$cod_empresa'";
$result_segunda_tabela = $conn->query($sql_segunda_tabela);

$sql_terceira_tabela = "SELECT cod_empresa, complemento, cep, telefone, email, data_emissao FROM tb_empresa WHERE cod_empresa = '$cod_empresa'";
$result_terceira_tabela = $conn->query($sql_terceira_tabela);

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informações Empresa</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>

    

<!--Header
---------------------------------------------------------------------------------------------------- -->
    <header class="header">
    <h1 class='h1_header'>Informações da empresa</h1>
        
        </header>
    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>



<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio_" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>
        <button class="btninicio" onclick="window.location.href='../interno.html'">Interno</button>
    </div>



<!--informações cadastrais
---------------------------------------------------------------------------------------------------- -->

<div class="quadcadastro_">

        <div class="tabela_info_cadstrais">
        <table border="2">
        <tr>
            <td class="td">Nome empresarial</td>
            <td class="td">Nome fantasia</td>
            <td class="td">CNPJ</td>
            <td class="td">Inscrição estadual</td>
            <td class="td">porte</td>
            <td class="td">Descrição de atividades</td>
        </tr>
        <?php
        while($user_data = mysqli_fetch_assoc($result))
        {
            echo"<tr>";
            echo"<td class='td'>".$user_data['nome_empresarial']."</td>";
            echo"<td class='td'>".$user_data['nome_fantasia']."</td>";
            echo"<td class='td'>".$user_data['cnpj']."</td>";
            echo"<td class='td'>".$user_data['inscricao_estadual']."</td>";
            echo"<td class='td'>".$user_data['porte']."</td>";
            echo "<td class='td'>";
            echo "<button onclick='toggleDescription(this)' class='expand-btn'>Expandir</button>";
            echo "<div class='desc-content' style='display: none;'>" . $user_data['desc_atividades'] . "</div>";
            echo "</td>";
            echo"</tr>";
            
                //echo"<td class='tdimg'><a href='alterar.php?cod_funcionario=".$user_data['cod_funcionario']."'><img src='../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
                //echo"<td><a href='#'><img src='../img/excluir.png' /></a></td>";
        }
        ?>
        
        <table border="2">
        <tr>
            <td class="td">País</td>
            <td class="td">Estado</td>
            <td class="td">Município</td>
            <td class="td">Bairro</td>
            <td class="td">Logradouro</td>
            <td class="td">Número</td>
        </tr>
        <?php
        while($user_data = mysqli_fetch_assoc($result_segunda_tabela))
        {
            echo"<tr>";
            echo"<td class='td'>".$user_data['pais']."</td>";
            echo"<td class='td'>".$user_data['estado']."</td>";
            echo"<td class='td'>".$user_data['municipio']."</td>";
            echo"<td class='td'>".$user_data['bairro']."</td>";
            echo"<td class='td'>".$user_data['logradouro']."</td>";
            echo"<td class='td'>".$user_data['numero']."</td>";
            echo"</tr>";
            
                //echo"<td class='tdimg'><a href='alterar.php?cod_funcionario=".$user_data['cod_funcionario']."'><img src='../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
                //echo"<td><a href='#'><img src='../img/excluir.png' /></a></td>";
        }
        ?>
        <br><br>
        <table border="2">
        <tr>
            <td class="td">Complemento</td>
            <td class="td">CEP</td>
            <td class="td">Telefone</td>
            <td class="td">Email</td>
            <td class="td">Data emissão</td>
        </tr>
        <?php
        while($user_data = mysqli_fetch_assoc($result_terceira_tabela))
        {
            echo"<tr>";
            echo"<td class='td'>".$user_data['complemento']."</td>";
            echo"<td class='td'>".$user_data['cep']."</td>";
            echo"<td class='td'>".$user_data['telefone']."</td>";
            echo"<td class='td'>".$user_data['email']."</td>";
            echo"<td class='td'>".$user_data['data_emissao']."</td>";
            echo"</tr>";
            
                echo"<td class='tdimg2'><a href='alterar_empresa_3.php?cod_empresa=".$user_data['cod_empresa']."'><img src='../../img/icons8-editar-64.png' style='width: 130%; height: 130%;' /></a></td>";
                //echo"<td><a href='#'><img src='../img/excluir.png' /></a></td>";
        }
        
        ?>
        <br><br>
        </table>
        </div>
</div>   

<script>
function toggleDescription(button) {
    var descContent = button.nextElementSibling;
    if (descContent.style.display === "none") {
        descContent.style.display = "block";
        button.textContent = "Contrair";
    } else {
        descContent.style.display = "none";
        button.textContent = "Expandir";
    }
}
</script>

</body>
</html>