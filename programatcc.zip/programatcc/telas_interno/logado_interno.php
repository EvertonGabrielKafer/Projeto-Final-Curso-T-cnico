<?php

session_start();
if (empty($_SESSION)) {
    
}
include_once('../php/mysqli.php');
$logado = $_SESSION['cpf'];
$sql = "SELECT * FROM tb_f_governo WHERE cpf = '$logado'";
$result = $conn->query($sql);
//print_r($result);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrado</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <link rel="stylesheet" href="../css/reset.css">
</head>
<body>

    

<!--Header
---------------------------------------------------------------------------------------------------- -->
<header class="header"><?php
        while($user_data = mysqli_fetch_assoc($result))
        {
            echo"<h1 class='h1_header'>Login interno bem sucedido, Olá ".$user_data['nome']."</h1>";
        }
        ?></header>
    <img class="logoceua" src="../img/logoceuremo.png">
    <a onclick="window.location.href='../php/logout.php'" class="logout"> <img class="logout_img" src="../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio" onclick="window.location.href='buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='relatorio.html'">Relatórios</button>
        <button class="btninicio" onclick="window.location.href='interno.html'">Interno</button>
    </div>


<!--Quadro de aviso
---------------------------------------------------------------------------------------------------- -->
    <div class="quadinicio">

        <img class="brasaoceua" src="../img/brasao.png">

        <h1 class="h1scf_cadastrado">Prezado funcionário interno;</h1>
        
        <p class="p2_logado">Você está no sistema de</p>
        <p class="p3_logado">cadastro de fornecedores da</p>
        <p class="p3_logado">Prefeitura Municipal de Céu Azul,</p>
        <p class="p3_logado">aqui você tem acesso aos dados</p>
        <p class="p3_logado">de todos os representantes e</p>
        <p class="p3_logado">empresas cadastrados.</p>
        <p class="p4_logado">Sistema desenvolvido por Everton Gabriel Käfer</p>
    </div>

</body>
</html>