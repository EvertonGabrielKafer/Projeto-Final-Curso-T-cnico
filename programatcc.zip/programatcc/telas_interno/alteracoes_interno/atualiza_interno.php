<?php
include_once('../../php/mysqli.php');
if(isset($_POST['update']))
{
    $cad_nome = $_POST['cad_nome'];
    $cad_cpf = $_POST['cad_cpf'];
    $cad_email = $_POST['cad_email'];
    $cad_senha = $_POST['cad_senha'];
    $cod_f_governo = $_POST['cod_f_governo'];

    $sqlatualiza = "UPDATE tb_f_governo SET nome='$cad_nome', cpf='$cad_cpf', email='$cad_email', senha='$cad_senha' WHERE cod_f_governo='$cod_f_governo'";
    $result = $conn->query($sqlatualiza);

    if ($result) {
        echo "<script>
        alert('Atualização de funcionario interno bem sucedida.');
        window.location.href = 'opcoes_interno.php';
        </script>";
    } else {
        echo "<script>
        alert('Erro.');
        window.location.href = 'opcoes_interno.php';
        </script>";
    }
}
?>