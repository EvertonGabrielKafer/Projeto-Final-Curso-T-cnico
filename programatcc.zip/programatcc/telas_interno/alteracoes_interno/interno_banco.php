<?php
    if(isset($_POST['submit']))
    {
        include_once('../../php/mysqli.php');
        
        $cad_cpf = $_POST['cad_cpf'];
        $cad_nome = $_POST['cad_nome'];
        $cad_email = $_POST['cad_email'];
        $cad_senha = $_POST['cad_senha'];
        


        $result = mysqli_query($conn, "  INSERT INTO tb_f_governo(cpf, nome, email, senha) values ('$cad_cpf','$cad_nome','$cad_email','$cad_senha')");

        echo "<script>
        alert('Cadastro de funcionario interno bem sucedido.');
        window.location.href = '../interno.html';
        </script>";
        
    }
    echo "<script>
        alert('Erro.');
        window.location.href = '../interno.html';
    </script>"
?>