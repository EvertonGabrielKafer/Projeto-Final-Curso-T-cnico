<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Interno</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    
    <header class="header">

    <h1 class='h1_header'>Cadastro de funcionario interno</h1>

    </header>

    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>
        <button class="btninicio_" onclick="window.location.href='../interno.html'">Interno</button>
    </div>


<!--cadastro
---------------------------------------------------------------------------------------------------- -->
    <div class="quadcadastro">
        

        

        <form action="interno_banco.php" method="post" class="form_principal">
            <p class="txtcadastro_centro">Nome:</p>
            <input type="text" name="cad_nome" class="inputcadastro_centro" required>
            <p class="txtcadastro_centro">CPF:</p>
            <input type="text" name="cad_cpf" class="inputcadastro_centro" required>
            <p class="txtcadastro_centro">Email:</p>
            <input type="email" name="cad_email" class="inputcadastro_centro" required>
            <p class="txtcadastro_centro">Senha:</p>
            <input type="password" name="cad_senha" class="inputcadastro_centro" required id="cad_senha">
            <p class="txtcadastro_centro">Confirmar Senha:</p>
            <input type="password" name="confirm_senha" class="inputcadastro_centro" required id="confirm_senha">
            
            <br>

        
            <input type="submit" class="cadastrar" name="submit" id="submit" value="ENVIAR">
            
        </form>
        
    </div>

</body>
</html>
<script>
    document.querySelector('.form_principal').addEventListener('submit', function(event) {
        const senha = document.getElementById('cad_senha').value;
        const confirmSenha = document.getElementById('confirm_senha').value;

        if (senha !== confirmSenha) {
            alert('As senhas não coincidem!');
            event.preventDefault();
        }
    });
</script>