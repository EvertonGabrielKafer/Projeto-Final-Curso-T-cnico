<?php


if(!empty($_GET['cod_f_governo']))
{
include_once('../../php/mysqli.php');
//echo "teste";

$cod_f_governo = $_GET['cod_f_governo'];

$sqlconsulta = "select * from tb_f_governo where cod_f_governo=$cod_f_governo";

$result = $conn->query($sqlconsulta);
//echo "teste";
//print_r($result);

if($result->num_rows>0){
    while($user_data = mysqli_fetch_assoc($result))
    {    
    $cad_nome =$user_data['nome'];
    $cad_cpf =$user_data['cpf'];
    $cad_email =$user_data['email'];
    $cad_senha =$user_data['senha'];
    }
    //print_r($cad_nome);
}
else{
    header('Location: opcoes_funcionario.php');
}


}else{echo"ruinou";}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Cadastro</title>
    <link rel="stylesheet" href="../../css/estilo.css">
    <link rel="stylesheet" href="../../css/reset.css">
</head>
<body>
<!--Header
---------------------------------------------------------------------------------------------------- -->
    
    <header class="header">

    <h1 class='h1_header'>Alterar o cadastro de represntente</h1>

    </header>

    <img class="logoceua" src="../../img/logoceuremo.png">
    <a onclick="window.location.href='../../php/logout.php'" class="logout"> <img class="logout_img" src="../../img/icons8-sair-48.png"> </a>


<!--Retangulo lateral
---------------------------------------------------------------------------------------------------- -->
    <div class="retangulo">
        <button class="btninicio" onclick="window.location.href='../Buscar_funcionario.php'">Mandatários</button>
        <button class="btninicio" onclick="window.location.href='../buscar_empresa.php'">Empresas</button>
        <button class="btninicio" onclick="window.location.href='../relatorio.html'">Relatórios</button>
        <button class="btninicio_" onclick="window.location.href='../interno.html'">Interno</button>
    </div>


<!--cadastro
---------------------------------------------------------------------------------------------------- -->
    <div class="quadcadastro">
        

        <form action="atualiza_interno.php" method="post" class="form_principal">
        <p class="txtcadastro_centro">Nome:</p>
            <input type="text" name="cad_nome" class="inputcadastro_centro" required value="<?php echo $cad_nome ?>">
            <p class="txtcadastro_centro">CPF:</p>
            <input type="text" name="cad_cpf" class="inputcadastro_centro" required value="<?php echo $cad_cpf ?>">
            <p class="txtcadastro_centro">Email:</p>
            <input type="email" name="cad_email" class="inputcadastro_centro" required value="<?php echo $cad_email ?>">
            <p class="txtcadastro_centro">Senha:</p>
            <input type="password" name="cad_senha" class="inputcadastro_centro" required id="cad_senha" value="<?php echo $cad_senha ?>">
            <p class="txtcadastro_centro">Confirmar Senha:</p>
            <input type="password" name="confirm_senha" class="inputcadastro_centro" required id="confirm_senha" value="<?php echo $cad_senha ?>">
            <br>

        
            <!--<input type="submit" class="cadastrar" name="submit" id="submit" value="ENVIAR">-->
            <input type="hidden" name="cod_f_governo" value="<?php echo $cod_f_governo ?>">
            <input type="submit" class="cadastrar" name="update" id="update">
            
            
        </form>
        
    </div>

</body>
</html>
<script>
    document.querySelector('.form_principal').addEventListener('submit', function(event) {
        const senha = document.getElementById('cad_senha').value;
        const confirmSenha = document.getElementById('confirm_senha').value;

        if (senha !== confirmSenha) {
            alert('As senhas não coincidem!');
            event.preventDefault();
        }
    });
</script>