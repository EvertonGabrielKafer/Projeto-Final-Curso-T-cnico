<?php

if(!empty($_GET['cod_f_governo']))
{
    
include_once('../../php/mysqli.php');
$cod_f_governo = $_GET['cod_f_governo'];

$sqlconsulta = "select * from tb_f_governo where cod_f_governo=$cod_f_governo";

$result = $conn->query($sqlconsulta);

if($result->num_rows>0){

    $sqldelete="delete from tb_f_governo where cod_f_governo=$cod_f_governo";    
    $resultdelete = $conn->query($sqldelete);
}
header('Location: opcoes_interno.php');
}
?>