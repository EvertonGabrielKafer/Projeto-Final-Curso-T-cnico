<?php

use Dompdf\Dompdf;

require_once 'dompdf/autoload.inc.php';

session_start();
if (empty($_SESSION)) {
    echo "<script>location.href='../php/empresa_banco.php';</script>";
}

require_once '../php/mysqli.php';

$logado = $_SESSION['cnpj'];
$query_empresa = "SELECT * FROM tb_empresa WHERE cnpj = '$logado'";
$result_empresa = $conn->prepare($query_empresa);
$result_empresa->execute();

$result = $result_empresa->get_result();



if (empty($_SESSION)) {
    echo "<script>location.href='cadastro_docs.php';</script>";
}
$sql_cod_empresa = "SELECT cod_empresa FROM tb_empresa WHERE cnpj = '$logado'";
$result_cod_empresa = mysqli_query($conn, $sql_cod_empresa);
$row = mysqli_fetch_assoc($result_cod_empresa);
$cod_empresa = $row['cod_empresa'];

$sql = "SELECT * FROM tb_documentos_pdf WHERE tb_empresa_cod_empresa = '$cod_empresa'";
$result2 = $conn->query($sql);



$dados = "<!DOCTYPE html>";
$dados .= "<html lang='pt-br'>";
$dados .= "<head>";
$dados .= "<meta charset='UTF-8'>";
$dados .= "<link rel='stylesheet' href='http://localhost/programas/programatcc/gerarpdf/gerarpdf.css'>";
$dados .= "<title>CRC</title>";
$dados .= "</head>";
$dados .= "<body>";
$dados .= "<img class='brasaoceuapdf' src='http://localhost/programas/programatcc/img/cabecalho.png'>";
$dados .= "<hr>";
$dados .= "<h1 class='titulo'>Certificado de Registro Cadastral C.R.C</h1>";
$dados.="<p>    <b>Este documento tem por objetivo comprovar o cadastro de uma empresa em caso de licitação,</b> além disto o representante deve conter este documento ao encaminhar-se ao Paço Municipal do município prestador da Licitação.</p>";
$dados .= "<br>";
$dados .= "<br>";
$dados .= "<h3 class='titulo'>Dados Empresariais</h3>";
$dados.="<p><b>Todas as informações cadastrais a baixo devem estar preenchidas,</b> com exceção do Nome Fantasia, <b>Caso contrário, o representante terá de realizar o cadastro empresarial ou atualiza-lo, e após isto re-emitir o C.R.C.</b></p>";

while ($row_empresa = $result->fetch_assoc()) {
    //var_dump($row_empresa);
    extract($row_empresa);
    
    $dados .= "ID: $cod_empresa <br>";
    $dados .= "Nome: $nome_empresarial <br>";
    $dados .= "Nome Fantasia: $nome_fantasia <br>";
    $dados .= "CNPJ: $cnpj <br>";
    $dados .= "Inscrição Estadual: $inscricao_estadual <br>";
    $dados .= "Porte: $porte <br>";
    $dados .= "Telefone: $telefone <br>";
    $dados .= "E-mail: $email <br>";
    $dados .= "País: $pais <br>";
    $dados .= "Estado: $estado <br>";
    $dados .= "Municípi: $municipio <br>";
    $dados .= "Bairro: $bairro <br>";
    $dados .= "Logaradouro: $logradouro <br>";
    $dados .= "Número: $numero <br>";
    $dados .= "Complemento: $complemento <br>";
    $dados .= "CEP: $cep <br>";
    $dados .= "Descrição Atividades: $desc_atividades <br>";
    $dados .= "<hr>";
}

$dompdf = new Dompdf(['enable_remote' => true]);

$dados .= "<br>";

$dados .= "<h3 class='titulo'>Documentos anexados</h3>";
$dados.="<p>    <b>Na tabela de documentos anexados, devem estar presentes os seguintes documentos:</b> Ato Constitutivo, Inscrição CNPJ, Inscrição Estadual, Alvará Municipal, Negativa Federal, Negativa Estadual, Negativa Municipal, Negativa FGTS, Negativa Trabalhista, Negativa de Falência e Concordata, Balanço Patrimonial, Atestado de Capacidade técnica e Inscrição no Conselho de Classe. <b>Caso contrário, o representante terá de anexar os documentos faltantes e re-emitir o C.R.C.</b></P>";

$dados.="<table border='1'>";
$dados.="<tr>";
$dados.="<td class='td'>Data de emissão</td>";
$dados.="<td class='td'>Data de validade</td>";
$dados.="<td class='td'>Tipo de documento</td>";
$dados.="</tr>";


    while($user_data = mysqli_fetch_assoc($result2)){
    $dados.="<tr>";
    $dados.="<td class='td'>".$user_data['data_eamissao']."</td>";
    $dados.="<td class='td'>".$user_data['data_validade']."</td>";
    $dados.="<td class='td'>".$user_data['tipo_doc']."</td>";
    $dados.="</tr>";
    };

$dados.="</table>";
$dados.="<hr>";
//$dados.="";


$dados .= "<p>Sistema de Cadastro de Fornecedor<p>";
$dados .= date('Y/m/d');
$dados .= "</body>";
$dados .= "</html>";

$dompdf->loadHtml($dados);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();


$nomeArquivo = "CRC_$nome_empresarial.pdf";


$dompdf->stream($nomeArquivo, ["Attachment" => false]);

?>