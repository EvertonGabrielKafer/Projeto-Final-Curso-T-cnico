<?php

use Dompdf\Dompdf;

require_once 'dompdf/autoload.inc.php';

require_once '../php/mysqli.php';

$query_empresa = "SELECT * FROM tb_empresa";
$result_empresa = $conn->prepare($query_empresa);
$result_empresa->execute();


$result = $result_empresa->get_result();

$dados = "<!DOCTYPE html>";
$dados .= "<html lang='pt-br'>";
$dados .= "<head>";
$dados .= "<meta charset='UTF-8'>";
$dados .= "<link rel='stylesheet' href='http://localhost/programas/programatcc/gerarpdf/gerarpdf.css'>";
$dados .= "<title>Relatório</title>";
$dados .= "</head>";
$dados .= "<body>";
$dados .= "<img class='brasaoceuapdf' src='http://localhost/programas/programatcc/img/cabecalho.png'>";
$dados .= "<hr>";
$dados .= "<h1 class='titulo'>Relatório de Empresas Cadastradas</h1>";
$dados .= "<br>";
$dados .= "<br>";


while ($row_empresa = $result->fetch_assoc()) {
    //var_dump($row_empresa);
    extract($row_empresa);
    
    $dados .= "ID: $cod_empresa <br>";
    $dados .= "Nome: $nome_empresarial <br>";
    $dados .= "Nome Fantasia: $nome_fantasia <br>";
    $dados .= "CNPJ: $cnpj <br>";
    $dados .= "Porte: $porte <br>";
    $dados .= "Telefone: $telefone <br>";
    $dados .= "E-mail: $email <br>";
    $dados .= "<hr>";
}

$dompdf = new Dompdf(['enable_remote' => true]);

$dados .= "<p>Sistema de Cadastro de Fornecedor<p>";
$dados .= date('Y/m/d');
$dados .= "</body>";
$dados .= "</html>";

$dompdf->loadHtml($dados);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();


$dataEmissao = date('Y-m-d');
$nomeArquivo = "relatorio_empresas_$dataEmissao.pdf";


$dompdf->stream($nomeArquivo, ["Attachment" => false]);

?>