<?php

use Dompdf\Dompdf;

require_once 'dompdf/autoload.inc.php';

require_once '../php/mysqli.php';

$query_funcionario = "SELECT * FROM tb_funcionario";
$result_funcionario = $conn->prepare($query_funcionario);
$result_funcionario->execute();


$result = $result_funcionario->get_result();

$dados = "<!DOCTYPE html>";
$dados .= "<html lang='pt-br'>";
$dados .= "<head>";
$dados .= "<meta charset='UTF-8'>";
$dados .= "<link rel='stylesheet' href='http://localhost/programas/programatcc/gerarpdf/gerarpdf.css'>";
$dados .= "<title>Relatório</title>";
$dados .= "</head>";
$dados .= "<body>";
$dados .= "<img class='brasaoceuapdf' src='http://localhost/programas/programatcc/img/cabecalho.png'>";
$dados .= "<hr>";
$dados .= "<h1 class='titulo'>Relatório de Representantes Cadastrados</h1>";
$dados .= "<br>";
$dados .= "<br>";


while ($row_funcionario = $result->fetch_assoc()) {
    //var_dump($row_funcionario);
    extract($row_funcionario);
    
    $dados .= "ID: $cod_funcionario <br>";
    $dados .= "CPF: $cpf <br>";
    $dados .= "RG: $rg <br>";
    $dados .= "Nome: $nome <br>";
    $dados .= "Telefone: $telefone <br>";
    $dados .= "E-mail: $email <br>";
    $dados .= "Data Nascimento: $data_nasc <br>";
    $dados .= "<hr>";
}

$dompdf = new Dompdf(['enable_remote' => true]);

$dados .= "<p>Sistema de Cadastro de Fornecedor<p>";
$dados .= date('Y/m/d');
$dados .= "</body>";
$dados .= "</html>";

$dompdf->loadHtml($dados);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();


$dataEmissao = date('Y-m-d');
$nomeArquivo = "relatorio_fornecedores_$dataEmissao.pdf";


$dompdf->stream($nomeArquivo, ["Attachment" => false]);

?>