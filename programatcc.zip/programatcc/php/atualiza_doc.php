<?php
        session_start();
        include_once('mysqli.php');

        if (empty($_SESSION)) {
            echo "<script>location.href='../php/cadastro_docs.php';</script>";
        }
        include_once('../php/mysqli.php');
        $logado = $_SESSION['cnpj'];

        if($_SERVER['REQUEST_METHOD']=='POST'){
            include('../php/mysqli.php');

            $data_validade = $_POST['data_validade'];
            $hoje = date('Y/m/d');
            $tipo_doc = $_POST['tipo_doc'];
            $conteudo_pdf = file_get_contents($_FILES['pdf']['tmp_name']);
            $cod_doc = $_POST['cod_doc'];

            $sql_cod_empresa = "SELECT cod_empresa FROM tb_empresa WHERE cnpj = '$logado'";
            $result_cod_empresa = mysqli_query($conn, $sql_cod_empresa);
            $row = mysqli_fetch_assoc($result_cod_empresa);
            $cod_empresa = $row['cod_empresa'];


            echo"<script>alert('teste');</script>";

            $sqlatualiza3 = "update tb_documentos_pdf set data_validade=?, data_eamissao=?, tipo_doc=?, pdf=?, tb_empresa_cod_empresa=? where cod_doc=?";           
            $stmt = $conn->prepare($sqlatualiza3);

            $stmt->bind_param("ssssss", $data_validade, $hoje, $tipo_doc, $conteudo_pdf, $cod_empresa, $cod_doc);
              
            echo"<script>alert('Validade".$data_validade."');</script>";
            echo"<script>alert('hj".$hoje."');</script>";
            echo"<script>alert('tipo doc".$tipo_doc."');</script>";
            echo"<script>alert('cod_doc".$cod_doc."');</script>";
            echo"<script>alert('cod empresa".$cod_empresa."');</script>";

            


            if($stmt->execute()){
                echo"<script>alert('Dados atualizados com Sucesso');</script>";
                
            }else{
                echo"<script>alert('Erro ao atualizar dados: ".$_SESSION["$stmt->error"]."');</script>";
            }
            

            $stmt->close();
            $conn->close();

          

        }


        



?>