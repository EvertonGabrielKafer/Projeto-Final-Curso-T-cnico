<?php
session_start();
if (empty($_SESSION)) {
    echo "<script>location.href='cadastro_docs.php';</script>";
    exit;
}

include_once('../php/mysqli.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT pdf FROM tb_documentos_pdf WHERE cod_doc = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($pdf);
    $stmt->fetch();
    $stmt->close();
    
    if ($pdf) {
        
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="documento.pdf"');
        echo $pdf;
    } else {
        echo "PDF não encontrado!";
    }
    exit;
}
?>