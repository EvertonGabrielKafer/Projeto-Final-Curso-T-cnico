<?php
    if(isset($_POST['submit']))
    {
        include_once('mysqli.php');
        
        $cad_cpf = $_POST['cad_cpf'];
        $cad_rg = $_POST['cad_rg'];
        $cad_nome = $_POST['cad_nome'];
        $cad_telefone = $_POST['cad_telefone'];
        $cad_email = $_POST['cad_email'];
        $cad_datanascimento = $_POST['cad_datanascimento'];
        $hoje = date('Y/m/d');
        $cad_senha = $_POST['cad_senha'];


        $result = mysqli_query($conn, "  INSERT INTO tb_funcionario(cpf, rg, nome, telefone, email, data_nasc, data_emissao, senha, tipo_func) values ('$cad_cpf','$cad_rg','$cad_nome','$cad_telefone','$cad_email','$cad_datanascimento','$hoje','$cad_senha','Admin')");

        echo"<script> location.href='../telas/cadastrado.html';</script>";
        
    }
    header('Location: ../telas/cadastrado.html')
?>