<?php
include_once('mysqli.php');

if(isset($_POST['update']))
{
$cod_funcionario=$_POST['cod_funcionario'];
$cad_nome = $_POST['cad_nome'];
$cad_rg =$_POST['cad_rg'];
$cad_telefone =$_POST['cad_telefone'];
$cad_datanascimento =$_POST['cad_datanascimento'];
$cad_cpf =$_POST['cad_cpf'];
$cad_email =$_POST['cad_email'];
$cad_senha =$_POST['cad_senha'];
$hoje = date('Y/m/d');

$sqlatualiza = "update tb_funcionario set nome='$cad_nome', rg='$cad_rg', 
telefone='$cad_telefone', data_nasc='$cad_datanascimento', cpf='$cad_cpf', 
email='$cad_email', senha='$cad_senha', data_emissao='$hoje' where cod_funcionario='$cod_funcionario'";
$result = $conn->query($sqlatualiza);

}
header('Location: ../telas/opcoes_funcionario.php');
?>