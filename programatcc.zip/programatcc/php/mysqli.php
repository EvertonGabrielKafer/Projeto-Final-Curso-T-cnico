<?php
    $host = "localhost";
    $bd = "bancotcc9";
    $usuario = "root";
    $senha = "";

    $conn = mysqli_connect($host, $usuario, $senha, $bd);
   
    //$mysqli = new mysqli($host, $usuario, $senha, $bd);

    if ($conn ->connect_errno){
        echo "falha ao conectar (" . $conn->connect_errno . ")"
         . $conn->connect_errno;

    }else{
        #echo "conectado ao banco $bd";
    }
?>