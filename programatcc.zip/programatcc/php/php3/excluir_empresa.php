<?php

if (!empty($_GET['cod_empresa'])) {
    include_once('../mysqli.php');
    $cod_empresa = $_GET['cod_empresa'];

    $sqlconsulta = "SELECT * FROM tb_empresa WHERE cod_empresa = $cod_empresa";
    $result = $conn->query($sqlconsulta);

    if ($result->num_rows > 0) {
        // Correção: coluna correta é tb_funcionario_cod_funcionario, não tb_funcionario_cod_empresa
        $sqldeletePDF = "DELETE FROM tb_documentos_pdf WHERE tb_empresa_cod_empresa = $cod_empresa";
        $conn->query($sqldeletePDF);

        $sqldeleteEmpresa = "DELETE FROM tb_empresa WHERE cod_empresa = $cod_empresa";
        $conn->query($sqldeleteEmpresa);
    }

    header('Location: ../../telas_interno/buscar_empresa.php');
}
?>