<?php

if(!empty($_GET['cod_doc']))
{
    
include_once('../mysqli.php');
$cod_doc = $_GET['cod_doc'];

$sqlconsulta = "select * from tb_documentos_pdf where cod_doc=$cod_doc";

$result = $conn->query($sqlconsulta);

if($result->num_rows>0){
    $sqldelete="delete from tb_documentos_pdf where cod_doc=$cod_doc";    
    $resultdelete = $conn->query($sqldelete);
}
header('Location: ../../telas_interno/buscar_empresa.php');
}
?>