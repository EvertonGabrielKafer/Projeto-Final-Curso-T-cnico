<?php
session_start();

include_once('../../php/mysqli.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('../../php/mysqli.php');

    $data_validade = $_POST['data_validade'];
    $hoje = date('Y/m/d');
    $tipo_doc = $_POST['tipo_doc'];
    $cod_doc = $_POST['cod_doc'];
    $cnpj = $_POST['cnpj'];

    // Verifica o tamanho do arquivo
    if ($_FILES['pdf']['size'] > 5000000) { // Limite de 5MB
        echo "<script>alert('O arquivo PDF é muito grande. Por favor, envie um arquivo menor.');</script>";
        exit();
    }

    // Obtém o conteúdo do arquivo PDF
    $conteudo_pdf = file_get_contents($_FILES['pdf']['tmp_name']);

    // Verifica se a conexão com o MySQL está ativa
    if (!$conn->ping()) {
        $conn->close();
        include('../../php/mysqli.php'); // Reabre a conexão
    }

    // Atualiza os dados no banco de dados
    $sqlatualiza2 = "UPDATE tb_documentos_pdf SET data_validade=?, data_eamissao=?, tipo_doc=?, pdf=? WHERE cod_doc=?";
    $stmt = $conn->prepare($sqlatualiza2);

    $stmt->bind_param("sssss", $data_validade, $hoje, $tipo_doc, $conteudo_pdf, $cod_doc);

    if ($stmt->execute()) {
        echo "<script>alert('Dados atualizados com Sucesso');</script>";
    } else {
        echo "<script>alert('Erro ao atualizar dados: " . $stmt->error . "');</script>";
    }

    $stmt->close();
    $conn->close();
}

header('Location: ../../telas_interno/buscar_empresa.php');
?>