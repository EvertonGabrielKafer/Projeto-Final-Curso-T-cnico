<?php

if(!empty($_GET['cod_funcionario']))
{
    
include_once('../mysqli.php');
$cod_funcionario = $_GET['cod_funcionario'];

$sqlconsulta = "select * from tb_funcionario where cod_funcionario=$cod_funcionario";

$result = $conn->query($sqlconsulta);

if($result->num_rows>0){
    $sqldeletePDF = "DELETE FROM tb_documentos_pdf WHERE tb_empresa_cod_empresa IN (SELECT cod_empresa FROM tb_empresa WHERE tb_funcionario_cod_funcionario = $cod_funcionario)";
    $conn->query($sqldeletePDF);

    $sqldeleteEmpresa = "DELETE FROM tb_empresa WHERE tb_funcionario_cod_funcionario = $cod_funcionario";
    $conn->query($sqldeleteEmpresa);

    $sqldelete="delete from tb_funcionario where cod_funcionario=$cod_funcionario";    
    $resultdelete = $conn->query($sqldelete);
}
header('Location: ../../telas_interno/buscar_funcionario.php');
}
?>