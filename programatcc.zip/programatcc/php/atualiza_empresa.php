<?php
session_start();
$logado = $_SESSION['cpf'];
include_once('mysqli.php');

if(isset($_POST['updateempresa']))
{
    $nome_empresarial = $_POST['nome_empresarial'];
    $cnpj = $_POST['cnpj'];
    $porte = $_POST['porte'];
    $pais = $_POST['pais'];
    $municipio = $_POST['municipio'];
    $logradouro = $_POST['logradouro'];
    $complemento = $_POST['complemento'];
    $telefone = $_POST['telefone'];
    $nome_fantasia = $_POST['nome_fantasia'];
    $inscricao_estadual = $_POST['inscricao_estadual'];
    $descricao_atividades = $_POST['descricao_atividades'];
    $estado = $_POST['estado'];
    $bairro = $_POST['bairro'];
    $numero = $_POST['numero'];
    $cep = $_POST['cep'];
    $email = $_POST['email'];
    $hoje = date('Y/m/d');
    $cod_empresa=$_POST['cod_empresa'];

    $sql_cod_funcionario = "SELECT cod_funcionario FROM tb_funcionario WHERE cpf = '$logado'";
    $result_cod_funcionario = mysqli_query($conn, $sql_cod_funcionario);
    $row = mysqli_fetch_assoc($result_cod_funcionario);
    $cod_funcionario = $row['cod_funcionario'];

$sqlatualiza = "update tb_empresa set nome_empresarial='$nome_empresarial', 
cnpj='$cnpj', porte='$porte', pais='$pais', municipio='$municipio',
logradouro='$logradouro', complemento='$complemento', nome_fantasia='$nome_fantasia',
inscricao_estadual='$inscricao_estadual', desc_atividades='$descricao_atividades', 
estado='$estado', bairro='$bairro', numero='$numero', cep='$cep', telefone = '$telefone',
email='$email', data_emissao='$hoje', tb_funcionario_cod_funcionario='$cod_funcionario' where cod_empresa='$cod_empresa'";
$result = $conn->query($sqlatualiza);

}
header('Location: ../telas/opcoes_empresa.php');


?>