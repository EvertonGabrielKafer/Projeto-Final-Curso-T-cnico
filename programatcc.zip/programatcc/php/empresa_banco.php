<?php
session_start();
if (empty($_SESSION)) {
    echo "<script>location.href='../php/cadastro_banco.php';</script>";
}
include_once('../php/mysqli.php');
$logado = $_SESSION['cpf'];

    if(isset($_POST['submitempresa']))
    {
        include_once('mysqli.php');
        
        $nome_empresarial = $_POST['nome_empresarial'];
        $cnpj = $_POST['cnpj'];
        $porte = $_POST['porte'];
        $pais = $_POST['pais'];
        $municipio = $_POST['municipio'];
        $logradouro = $_POST['logradouro'];
        $complemento = $_POST['complemento'];
        $telefone = $_POST['telefone'];
        $nome_fantasia = $_POST['nome_fantasia'];
        $inscricao_estadual = $_POST['inscricao_estadual'];
        $descricao_atividades = $_POST['descricao_atividades'];
        $estado = $_POST['estado'];
        $bairro = $_POST['bairro'];
        $numero = $_POST['numero'];
        $cep = $_POST['cep'];
        $email = $_POST['email'];
        $hoje = date('Y/m/d');
        
        $sql_cod_funcionario = "SELECT cod_funcionario FROM tb_funcionario WHERE cpf = '$logado'";
        $result_cod_funcionario = mysqli_query($conn, $sql_cod_funcionario);
        $row = mysqli_fetch_assoc($result_cod_funcionario);
        $cod_funcionario = $row['cod_funcionario'];


        $result = mysqli_query($conn, "  INSERT INTO tb_empresa(nome_empresarial, nome_fantasia, cnpj, inscricao_estadual, porte, desc_atividades, pais, estado, municipio, bairro, logradouro, numero, complemento, cep, telefone, email, data_emissao, tb_funcionario_cod_funcionario) values ('$nome_empresarial','$nome_fantasia','$cnpj','$inscricao_estadual','$porte','$descricao_atividades','$pais','$estado','$municipio','$bairro','$logradouro','$numero','$complemento','$cep','$telefone','$email','$hoje','$cod_funcionario')");

        
    }
    echo "<script>
        alert('Realize o login para confirmar o cadastro de empresa.');
        window.location.href = '../telas/login.html';
    </script>";

?>
