<?php
    session_start();
    if(empty($_POST) or (empty($_POST["cpf"]) or (empty($_POST["senha"])))){
        echo "<script> location.href='../telas_interno/login_int.php';</script>";
    }
    include("mysqli.php");
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];
    $sql = "select * from tb_f_governo where cpf = '{$cpf}'
    AND senha ='{$senha}'";
    $res = $conn->query($sql) or die($conn->error);   
    $row = $res->fetch_object();
    $qtd = $res->num_rows;
    if($qtd > 0){
        $_SESSION["cpf"] = $cpf;
        $_SESSION["senha"] = $senha;
        
        
        echo"<script> location.href='../telas_interno/logado_interno.php';</script>";
    }else{
        echo"<script>alert('usuario ou senha invalido');</script>";
        echo"<script>location.href='../telas_interno/login_int.php';</script>";
    }
?>