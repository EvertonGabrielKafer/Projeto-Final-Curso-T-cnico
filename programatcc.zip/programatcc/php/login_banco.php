
<?php
    session_start();
    if(empty($_POST) or (empty($_POST["cpf"]) or (empty($_POST["senha"])))){
        echo "<script> location.href='../telas/login.html';</script>";
    }
    include("mysqli.php");
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];
    $sql = "select * from tb_funcionario where cpf = '{$cpf}'
    AND senha ='{$senha}'";
    $res = $conn->query($sql) or die($conn->error);   
    $row = $res->fetch_object();
    $qtd = $res->num_rows;
    if($qtd > 0){
        $_SESSION["cpf"] = $cpf;
        $_SESSION["senha"] = $senha;
        $codfuncionario= $row->cod_funcionario;
        $sql2="select cnpj from tb_empresa where tb_funcionario_cod_funcionario = '{$codfuncionario}'";
        $res2 = $conn->query($sql2) or die($conn->error);  
        $row2 = $res2->fetch_object(); 
        $qtd2 = $res2->num_rows;
        if ($qtd2 > 0){
            $_SESSION["cnpj"] = $row2->cnpj;
        //echo"<script>alert('".$_SESSION["cnpj"]."');</script>";
        }
        
        echo"<script> location.href='../telas/logado.php';</script>";
    }else{
        echo"<script>alert('usuario ou senha invalido');</script>";
        echo"<script>location.href='../telas/login.html';</script>";
    }
?>